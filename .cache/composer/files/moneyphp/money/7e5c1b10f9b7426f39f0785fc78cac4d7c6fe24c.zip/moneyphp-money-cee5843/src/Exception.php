<?php

declare(strict_types=1);

namespace Money;

/**
 * Common interface for all exceptions thrown by this library.
 */
interface Exception
{
}

<?php

namespace Overtrue\LaravelFavorite\Events;

class Unfavorited extends Event
{
}

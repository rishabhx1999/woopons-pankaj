<?php

namespace Overtrue\LaravelFavorite\Events;

class Favorited extends Event
{
}

<div class="w-full mx-2 py-1 mt-1 bg-yellow text-black text-center uppercase">
    <?php echo htmlspecialchars($content) ?>
</div>
